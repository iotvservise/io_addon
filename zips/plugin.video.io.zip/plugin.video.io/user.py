import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLnNtYXJ0aXB0dnNwYWluLTQ=')

name = b.b64decode('W0NPTE9SIGxpbWVdU21hcnRJcHR2U3BhaW4tWy9DT0xPUl1bQ09MT1IgcmVkXSA0Wy9DT0xPUl0=')

host = b.b64decode('aHR0cDovLzE0NC4yMTcuNzcuNQ==')

port = b.b64decode('MjU0NjE=')